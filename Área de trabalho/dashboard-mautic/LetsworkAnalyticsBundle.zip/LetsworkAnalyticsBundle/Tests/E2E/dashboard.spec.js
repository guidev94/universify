/**
 * LetsWork Analytics — E2E Test Spec
 * Run with: npx playwright test Tests/E2E/dashboard.spec.js
 * Requires: Mautic running on localhost:6001 with plugin installed
 */

const { test, expect } = require('@playwright/test');

const BASE_URL = process.env.MAUTIC_URL || 'http://localhost:6001';
const LOGIN_USER = process.env.MAUTIC_USER || 'admin';
const LOGIN_PASS = process.env.MAUTIC_PASS || 'Mautic@2026!';

test.beforeEach(async ({ page }) => {
    await page.goto(`${BASE_URL}/s/login`);
    await page.fill('#username', LOGIN_USER);
    await page.fill('#password', LOGIN_PASS);
    await page.click('button[type="submit"]');
    await page.waitForURL('**/s/dashboard**', { timeout: 10000 });
});

test.describe('Dashboard Overview', () => {
    test('loads without console errors', async ({ page }) => {
        const errors = [];
        page.on('console', msg => { if (msg.type() === 'error') errors.push(msg.text()); });
        await page.goto(`${BASE_URL}/s/analytics/overview`);
        await page.waitForSelector('.lwa-kpi-row', { timeout: 10000 });
        expect(errors.filter(e => !e.includes('favicon'))).toHaveLength(0);
    });

    test('KPI cards display numbers', async ({ page }) => {
        await page.goto(`${BASE_URL}/s/analytics/overview`);
        await page.waitForSelector('.lwa-kpi-value');
        const values = await page.$$eval('.lwa-kpi-value', els => els.map(e => e.textContent.trim()));
        values.forEach(v => {
            expect(v).not.toBe('');
            expect(v).not.toBe('NaN');
            expect(v).not.toBe('undefined');
        });
    });

    test('clicking KPI opens detail modal', async ({ page }) => {
        await page.goto(`${BASE_URL}/s/analytics/overview`);
        await page.waitForSelector('.lwa-kpi-card');
        await page.click('.lwa-kpi-card:first-child');
        await page.waitForSelector('#lwa-kpi-detail', { state: 'visible', timeout: 5000 });
        expect(await page.isVisible('#lwa-kpi-detail')).toBe(true);
    });

    test('Smart Alerts loads', async ({ page }) => {
        await page.goto(`${BASE_URL}/s/analytics/overview`);
        await page.waitForSelector('#lwa-smart-alerts');
        await page.waitForTimeout(3000);
        const content = await page.$eval('#lwa-smart-alerts .lwa-card-body', el => el.innerHTML);
        expect(content).not.toContain('ri-loader');
    });

    test('AI Insights auto-generates', async ({ page }) => {
        await page.goto(`${BASE_URL}/s/analytics/overview`);
        await page.waitForSelector('#lwa-insights');
        await page.waitForTimeout(5000);
        const content = await page.$eval('#lwa-insights .lwa-card-body', el => el.innerHTML);
        expect(content).not.toContain('Gerando insights');
    });

    test('notification bell shows badge', async ({ page }) => {
        await page.goto(`${BASE_URL}/s/analytics/overview`);
        await page.waitForSelector('.lwa-notification-bell');
        const bell = await page.$('.lwa-notification-bell');
        expect(bell).not.toBeNull();
    });
});

test.describe('Lead Modal', () => {
    test('opens and displays lead data', async ({ page }) => {
        await page.goto(`${BASE_URL}/s/analytics/overview`);
        await page.waitForSelector('.lwa-kpi-card');
        await page.click('.lwa-kpi-card:first-child');
        await page.waitForSelector('.lwa-table-row-interactive', { timeout: 10000 });
        await page.click('.lwa-table-row-interactive:first-child');
        await page.waitForSelector('#lwa-lead-modal', { state: 'visible', timeout: 5000 });
        const title = await page.$eval('#lwa-modal-title', el => el.textContent);
        expect(title).not.toBe('Carregando...');
        expect(title.length).toBeGreaterThan(1);
    });

    test('WhatsApp button opens modal (not external link)', async ({ page }) => {
        await page.goto(`${BASE_URL}/s/analytics/overview`);
        await page.waitForSelector('.lwa-kpi-card');
        await page.click('.lwa-kpi-card:first-child');
        await page.waitForSelector('.lwa-table-row-interactive', { timeout: 10000 });
        await page.click('.lwa-table-row-interactive:first-child');
        await page.waitForSelector('#lwa-lead-modal', { state: 'visible' });
        const waBtn = await page.$('button:has-text("WhatsApp")');
        if (waBtn) {
            await waBtn.click();
            await page.waitForTimeout(500);
            const body = await page.$eval('#lwa-modal-body', el => el.innerHTML);
            expect(body).toContain('lwa-wa-message');
        }
    });

    test('Follow-up rejects past dates', async ({ page }) => {
        await page.goto(`${BASE_URL}/s/analytics/overview`);
        await page.waitForSelector('.lwa-kpi-card');
        await page.click('.lwa-kpi-card:first-child');
        await page.waitForSelector('.lwa-table-row-interactive', { timeout: 10000 });
        await page.click('.lwa-table-row-interactive:first-child');
        await page.waitForSelector('#lwa-lead-modal', { state: 'visible' });
        const followBtn = await page.$('button:has-text("Follow-up")');
        if (followBtn) {
            await followBtn.click();
            await page.waitForTimeout(500);
            await page.fill('#lwa-followup-date', '2020-01-01');
            await page.click('button:has-text("Agendar")');
            await page.waitForTimeout(500);
        }
    });

    test('Timeline loads without Invalid Date', async ({ page }) => {
        await page.goto(`${BASE_URL}/s/analytics/overview`);
        await page.waitForSelector('.lwa-kpi-card');
        await page.click('.lwa-kpi-card:first-child');
        await page.waitForSelector('.lwa-table-row-interactive', { timeout: 10000 });
        await page.click('.lwa-table-row-interactive:first-child');
        await page.waitForSelector('#lwa-lead-modal', { state: 'visible' });
        const timelineBtn = await page.$('button:has-text("Timeline")');
        if (timelineBtn) {
            await timelineBtn.click();
            await page.waitForTimeout(3000);
            const content = await page.$eval('#lwa-timeline-result', el => el.innerHTML);
            expect(content).not.toContain('Invalid Date');
        }
    });
});

test.describe('Security', () => {
    test('XSS in lead name does not execute', async ({ page }) => {
        const alerts = [];
        page.on('dialog', dialog => { alerts.push(dialog.message()); dialog.dismiss(); });
        await page.goto(`${BASE_URL}/s/analytics/overview`);
        await page.waitForSelector('.lwa-kpi-card');
        await page.waitForTimeout(3000);
        expect(alerts).toHaveLength(0);
    });
});

test.describe('Responsive', () => {
    test('mobile viewport does not overflow', async ({ page }) => {
        await page.setViewportSize({ width: 375, height: 812 });
        await page.goto(`${BASE_URL}/s/analytics/overview`);
        await page.waitForSelector('.lwa-analytics-page');
        const overflow = await page.evaluate(() => {
            return document.querySelector('.lwa-analytics-page').scrollWidth > window.innerWidth + 10;
        });
        expect(overflow).toBe(false);
    });
});
