<?php

namespace MauticPlugin\LetsworkAnalyticsBundle\Tests\Unit;

use PHPUnit\Framework\TestCase;
use MauticPlugin\LetsworkAnalyticsBundle\Model\AnalyticsModel;
use ReflectionClass;

class AnalyticsModelTest extends TestCase
{
    private function invokePrivateMethod(object $obj, string $method, array $args = [])
    {
        $ref = new ReflectionClass($obj);
        $m = $ref->getMethod($method);
        $m->setAccessible(true);
        return $m->invoke($obj, ...$args);
    }

    private function createModelWithoutDb(): AnalyticsModel
    {
        $ref = new ReflectionClass(AnalyticsModel::class);
        return $ref->newInstanceWithoutConstructor();
    }

    public function testInferSegmento_Tecnologia(): void
    {
        $model = $this->createModelWithoutDb();
        $result = $this->invokePrivateMethod($model, 'inferSegmento', ['Desenvolvimento de software sob encomenda', 'TechCorp LTDA']);
        $this->assertEquals('Tecnologia', $result);
    }

    public function testInferSegmento_Saude(): void
    {
        $model = $this->createModelWithoutDb();
        $result = $this->invokePrivateMethod($model, 'inferSegmento', ['Atividades de atendimento hospitalar', 'Hospital São Lucas']);
        $this->assertEquals('Saúde', $result);
    }

    public function testInferSegmento_Educacao(): void
    {
        $model = $this->createModelWithoutDb();
        $result = $this->invokePrivateMethod($model, 'inferSegmento', ['Educação superior - graduação', 'Universidade ABC']);
        $this->assertEquals('Educação', $result);
    }

    public function testInferSegmento_Unknown(): void
    {
        $model = $this->createModelWithoutDb();
        $result = $this->invokePrivateMethod($model, 'inferSegmento', ['Atividade não classificada', 'Empresa XYZ']);
        $this->assertEquals('Outros', $result);
    }

    public function testBuildGoogleCalendarUrl_Format(): void
    {
        $model = $this->createModelWithoutDb();
        $url = $this->invokePrivateMethod($model, 'buildGoogleCalendarUrl', [
            'Reunião Teste', '20260615T100000', '20260615T103000', 'Descrição teste', 'lead@test.com'
        ]);

        $this->assertStringStartsWith('https://calendar.google.com/calendar/render?', $url);
        $this->assertStringContainsString('action=TEMPLATE', $url);
        $this->assertStringContainsString('text=Reuni', $url);
        $this->assertStringContainsString('add=lead%40test.com', $url);
    }

    public function testBuildEmailHtml_Structure(): void
    {
        $model = $this->createModelWithoutDb();
        $html = $this->invokePrivateMethod($model, 'buildEmailHtml', ['Olá mundo', 'João', 'Admin']);

        $this->assertStringContainsString('<!DOCTYPE html>', $html);
        $this->assertStringContainsString('Ol&aacute; mundo', $html);
        $this->assertStringContainsString('Admin', $html);
        $this->assertStringContainsString('LetsWork', $html);
    }

    public function testBuildEmailHtml_EscapesXSS(): void
    {
        $model = $this->createModelWithoutDb();
        $html = $this->invokePrivateMethod($model, 'buildEmailHtml', ['<script>alert(1)</script>', 'Test', 'Admin']);

        $this->assertStringNotContainsString('<script>', $html);
        $this->assertStringContainsString('&lt;script&gt;', $html);
    }

    public function testNormalizeCnpjResponse_BrasilAPI(): void
    {
        $model = $this->createModelWithoutDb();
        $raw = [
            'razao_social' => 'LetsWork Tecnologia LTDA',
            'nome_fantasia' => 'LetsWork',
            'cnpj' => '12345678000199',
            'porte' => 'PEQUENO',
            'cnae_fiscal_descricao' => 'Desenvolvimento de software',
            'capital_social' => 100000,
            'uf' => 'SP',
            'municipio' => 'São Paulo',
            'data_inicio_atividade' => '2020-01-15',
            'descricao_situacao_cadastral' => 'ATIVA',
            'qsa' => [['nome_socio' => 'João Silva', 'qualificacao_socio' => 'Sócio-Administrador']],
        ];

        $result = $this->invokePrivateMethod($model, 'normalizeCnpjResponse', [$raw]);

        $this->assertEquals('LetsWork Tecnologia LTDA', $result['razao_social']);
        $this->assertEquals('Tecnologia', $result['segmento']);
        $this->assertEquals('PEQUENO', $result['porte']);
        $this->assertCount(1, $result['socios']);
    }

    public function testNormalizeCnpjResponse_ReceitaWS(): void
    {
        $model = $this->createModelWithoutDb();
        $raw = [
            'nome' => 'Empresa Saúde LTDA',
            'fantasia' => 'CliniSaúde',
            'cnpj' => '98765432000188',
            'porte' => 'MEDIO',
            'atividade_principal' => [['text' => 'Atividades de atendimento hospitalar']],
            'capital_social' => '500000.00',
            'uf' => 'RJ',
            'municipio' => 'Rio de Janeiro',
            'abertura' => '01/03/2015',
            'situacao' => 'ATIVA',
            'qsa' => [['nome' => 'Maria Santos', 'qual' => 'Sócia']],
            'telefone' => '2133334444',
            'email' => 'contato@clinisaude.com.br',
        ];

        $result = $this->invokePrivateMethod($model, 'normalizeCnpjResponse', [$raw]);

        $this->assertEquals('Empresa Saúde LTDA', $result['razao_social']);
        $this->assertEquals('Saúde', $result['segmento']);
        $this->assertEquals('contato@clinisaude.com.br', $result['email_empresa']);
    }

    public function testLwaEscHelper_Concept(): void
    {
        $input = "O'Brien & <Co>";
        $escaped = str_replace(['\\', "'", '"', '<', '>', "\n"], ['\\\\', "\\'", '\\"', '', '', ' '], $input);
        $this->assertStringNotContainsString('<', $escaped);
        $this->assertStringNotContainsString("'", $escaped);
    }
}
